SELECT user, host FROM mysql.user WHERE user LIKE '%qgo%' OR user LIKE '%wms%';
